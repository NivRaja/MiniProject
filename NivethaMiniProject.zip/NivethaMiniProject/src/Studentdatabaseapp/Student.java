package Studentdatabaseapp;

import java.util.Scanner;

public class Student {
	private String firstName;
	private String LastName;
	private int gradeYear;
	private String studentID;
	private String courses;
	private int tuitionBalance;
	private static int costOfCourse=600;
	private static int id = 1000;
	
	public Student() {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter Student First Name:");
		this.firstName = in.nextLine();
		
		System.out.print("Enter Student last Name:");
		this.LastName = in.nextLine();
		
		System.out.print("1 - Freshmen\n2- forsopmore\n3 - Junior\n4- Senior\n.Enter Student class Level:");
		this.gradeYear = in.nextInt();
		
		setStudentID();
		
		System.out.println(firstName + " " + LastName + " " + gradeYear + " " + studentID);
		
		
	}
	
	
	private void setStudentID() {
		id++;
		this.studentID = gradeYear + " " + id;
		
	}
	
	public void enroll() {
		do {
		
		System.out.println("Enter Course to Enroll (Q to quite): ");
		Scanner in= new Scanner(System.in);
		String course= in.nextLine();
		
		if(!course.equals("Q"))
		{
			courses=courses + "\n" + course;
			tuitionBalance= tuitionBalance + costOfCourse;
		}
		else {
			System.out.println("Break!");
			break;
			}
	}while (1 != 0);
		
		System.out.println("Enrolled IN:" +courses);
		System.out.println("Tution Balance:" +tuitionBalance);
		
	}
	
	public void viewBalance() {
		System.out.println("Your Balance is: $" + tuitionBalance);
	}
	
	public void payTuition() {
		viewBalance();
		System.out.print("enter your Payment");
		Scanner in= new Scanner(System.in);
		int  payment = in.nextInt();
		tuitionBalance = tuitionBalance - payment;
		System.out.println("Thank You for Your Payment of $" + payment);
		viewBalance();
	}

	public String toString()
	{
		return "Name:" + firstName + " " + LastName + 
				"\n StudentId:" + studentID+
				"\nCourses Enrolled:" +courses + 
				"\nBalance : $" + tuitionBalance;
	}

}
