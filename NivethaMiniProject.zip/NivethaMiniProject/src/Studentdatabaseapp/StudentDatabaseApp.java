package Studentdatabaseapp;

public class StudentDatabaseApp {

	public static void main(String[] args) {
		Student stu1= new Student();
		
		stu1.enroll();
		stu1.payTuition();
		System.out.println(stu1.toString());
		
         Student stu2= new Student();
		
		stu2.enroll();
		stu2.payTuition();
		System.out.println(stu2.toString());

	}

}
